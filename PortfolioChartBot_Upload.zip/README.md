
# Portfolio Chart Telegram Bot

## 🔧 Інструкція запуску через Render

1. Завантаж цей код у свій GitHub репозиторій
2. Створи Web Service на [https://render.com](https://render.com)
3. У полі **Start Command** впиши:
   ```
   python main.py
   ```
4. Додай змінну середовища:
   - `BOT_TOKEN=тут_встав_свій_токен`

5. Натисни **Deploy** — і бот буде працювати в Telegram!
