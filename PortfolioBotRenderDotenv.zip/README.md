# Portfolio Bot

Telegram бот, адаптований для Render з використанням dotenv.